sh examples/docker/run_elastic_search.sh
python quick-start-demo.py --config_path=memoryscope/core/config/demo_config_zh.yaml