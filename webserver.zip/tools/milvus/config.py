
class Config:
    MILVUS_HOST = '202.127.200.31'
    MILVUS_PORT = '30007'
    COLLECTION_NAME = 'default'
    DIMENSION = 768
    MODEL_NAME = "D:/czdemo/czpaperdemo/guidance/llm-chat-demo-master/flask_backend/milvus/text2vec-base-chinese"
    TEXT_CHUNK_SIZE = 200


