#数据库信息
mysqlurl="118.25.137.23"
mysqlport="3306"
mysqlname="gptapp"
mysqlaccount="gptapp"
mysqlpassword="gptapp"