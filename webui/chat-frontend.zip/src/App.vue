<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
#app {
  width: 100%;
  height: 100%;
  padding: 0;
  margin: 0;
  overflow: hidden;
}
html{
  height: 100%;
}
body{
  height: 100%;
  margin: 0;
  //font-family: Arial,serif;
}
</style>
