# node -v 
v14.17.3

# npm -v
6.14.13

